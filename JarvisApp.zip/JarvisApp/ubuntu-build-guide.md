# Build the Jarvis APK on Ubuntu — step by step

Goal: turn the JarvisApp project into an installable APK on Mohammad's phone.

## Step 1 — Install Android Studio on the laptop

Open a terminal on Ubuntu and run:

```bash
sudo snap install android-studio --classic
```

(If snap is not available, download Android Studio from
https://developer.android.com/studio and extract it instead.)

Then launch Android Studio once and finish its setup wizard. When it asks
about the Android SDK, accept the defaults — it installs the SDK itself.

## Step 2 — Get the project onto the laptop

Copy `JarvisApp.zip` to the laptop, unzip it, and remember the folder path.

## Step 3 — Open the project

In Android Studio: **File → Open**, pick the `JarvisApp` folder, and wait for
the Gradle sync to finish (first time takes a few minutes — it downloads
dependencies). If it asks to install anything (SDK parts, etc.), accept.

## Step 4 — Prepare the phone

On the phone:
1. Settings → About phone → tap **Build number** 7 times (enables Developer options)
2. Settings → System → Developer options → turn on **USB debugging**
3. Connect the phone to the laptop with a USB cable
4. On the phone popup, tap **Allow** (and "Always allow from this computer")

## Step 5 — Run it

In Android Studio, click the green **Run** (▶) button with the phone selected.
The Jarvis app installs on the phone.

## Step 6 — On the phone

1. Open Jarvis, tap **Start Jarvis**, allow the mic
2. Tap the battery button so Android doesn't kill it in the background
3. Say: "Hey Jarvis, what time is it"

## If he wants a shareable APK file instead

Android Studio → **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
The APK appears at:
`JarvisApp/app/build/outputs/apk/debug/app-debug.apk`
Copy it to the phone and tap it to install.

## Troubleshooting

- Gradle sync fails → check internet, then File → Sync Project with Gradle Files
- Phone not detected → try another cable/USB port, re-allow the USB debugging popup
- App stops listening in background → battery button step, plus phone Settings →
  Apps → Jarvis → Battery → Unrestricted
