package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Jarvis, running in the background as a foreground service.
 *
 * How it works: the mic stays on, listening only for the wake word "Jarvis".
 * Say "Hey Jarvis" (or "Hey Jarvis, <command>" in one breath) and it answers
 * out loud, then goes back to listening for the wake word.
 *
 * Honest limits of Android: a normal app cannot listen while the phone is
 * fully asleep like Siri/Google Assistant can — that needs the system
 * assistant role. With this foreground service Jarvis keeps listening while
 * the phone is awake and the service runs; turn off battery optimization
 * for Jarvis in Settings so Android does not kill it.
 */
class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_LOG = "com.jarvis.assistant.LOG"
        const val EXTRA_LINE = "line"
        private const val CHANNEL_ID = "jarvis_listening"
        private const val NOTIF_ID = 1
        private const val WAKE_WORD = "jarvis"
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaitingCommand = false
    private var commandTimer: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    override fun onCreate() {
        super.onCreate()
        startForegroundNotif()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) {
            running = true
            log("Jarvis is listening in the background. Say \"Hey Jarvis\".")
            startListening()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        stopListening()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- Foreground notification ----------

    private fun startForegroundNotif() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Jarvis listening",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S is listening")
            .setContentText("Say \"Hey Jarvis\" any time")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    // ---------- Speech in ----------

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Speech recognition is not available on this phone.")
            return
        }
        stopListening()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    // Mic pauses are normal; just restart listening.
                    if (running) handler.postDelayed({ startListening() }, 400)
                }

                override fun onResults(results: Bundle?) {
                    val heard = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim() ?: ""
                    if (heard.isNotEmpty()) onHeard(heard)
                    if (running) handler.postDelayed({ startListening() }, 200)
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            try {
                startListening(intent)
            } catch (e: Exception) {
                log("Could not start listening: ${e.message}")
            }
        }
    }

    private fun stopListening() {
        try {
            recognizer?.stopListening()
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
    }

    private fun onHeard(heard: String) {
        log("Heard: $heard")
        val lower = heard.lowercase()
        if (awaitingCommand) {
            awaitingCommand = false
            commandTimer?.let { handler.removeCallbacks(it) }
            handleCommand(heard)
            return
        }
        val idx = lower.indexOf(WAKE_WORD)
        if (idx == -1) return // ignore everything until the wake word
        val rest = heard.substring(idx + WAKE_WORD.length)
            .trim().trimStart(',', '.', ' ')
        if (rest.isNotEmpty()) {
            handleCommand(rest)
        } else {
            awaitingCommand = true
            speak("Yes?")
            commandTimer = Runnable { awaitingCommand = false }
            handler.postDelayed(commandTimer!!, 10_000)
        }
    }

    // ---------- Speech out ----------

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
            ttsReady = true
        }
    }

    private fun speak(text: String) {
        log("Jarvis: $text")
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun log(line: String) {
        val intent = Intent(ACTION_LOG).putExtra(EXTRA_LINE, line)
        sendBroadcast(intent)
    }

    // ---------- Commands ----------

    private fun handleCommand(raw: String) {
        val text = raw.trim()
        val lower = text.lowercase()

        // Time & date
        if (lower.contains("time")) {
            val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            speak("It is $time.")
            return
        }
        if (lower.contains("date") || lower.contains("day is it") || lower == "today") {
            val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            speak("Today is $date.")
            return
        }
        if (lower.contains("joke")) {
            speak(
                listOf(
                    "Why did the developer go broke? Because he used up all his cache.",
                    "I would tell you a UDP joke, but you might not get it.",
                    "Why do programmers prefer dark mode? Because light attracts bugs."
                ).random()
            )
            return
        }
        if (lower.contains("stop") && lower.contains("listening")) {
            speak("Going quiet. Say Hey Jarvis when you need me.")
            return
        }

        // Open an app: "open whatsapp"
        val openMatch = Regex("open\\s+(.+)").find(lower)
        if (openMatch != null) {
            val appName = openMatch.groupValues[1].trim()
            if (AppLauncher.openApp(this, appName)) {
                speak("Opening $appName.")
            } else {
                speak("I could not find an app called $appName on this phone.")
            }
            return
        }

        // Play music: "play lofi" -> YouTube Music search
        if (lower.startsWith("play ")) {
            val song = text.substring(5).trim()
            openUrl("https://music.youtube.com/search?q=${song.replace(' ', '+')}")
            speak("Playing $song.")
            return
        }

        // Weather: "weather in Delhi"
        val weatherMatch = Regex("weather(?: in)?\\s+(.+)").find(lower)
        if (weatherMatch != null) {
            val city = weatherMatch.groupValues[1].trim()
            Brain.weather(city) { answer ->
                speak(answer ?: "I could not get the weather for $city right now.")
            }
            return
        }

        // Places: "where is Dal Lake" / "find petrol pump near me"
        if (lower.startsWith("where is ") || lower.startsWith("find ")) {
            val place = text.substringAfter("where is ", "")
                .substringAfter("find ", "").trim()
            Brain.findPlace(place) { found ->
                if (found != null) {
                    speak("I found ${found.name}. Opening it on the map.")
                    openUrl("https://www.google.com/maps/search/?api=1&query=${found.lat},${found.lon}")
                } else {
                    speak("I could not find $place.")
                }
            }
            return
        }

        // Web search: "search cats"
        val searchMatch = Regex("^(search|google)( for)?\\s+(.+)").find(lower)
        if (searchMatch != null) {
            val query = searchMatch.groupValues[3]
            openUrl("https://www.google.com/search?q=${query.replace(' ', '+')}")
            speak("Searching for $query.")
            return
        }

        // General question -> spoken web answer, browser as backup
        Brain.answerQuestion(text) { answer ->
            if (answer != null) {
                speak(answer)
            } else {
                speak("I did not find a direct answer. Let me search the web for you.")
                openUrl("https://www.google.com/search?q=${text.replace(' ', '+')}")
            }
        }
    }

    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            log("Could not open link: ${e.message}")
        }
    }
}
